#1.

M<-matrix(nrow=2,ncol=3)
M
dim(M)


#2.
M1<-matrix(1:6,nrow=2,ncol=3)
M1

#3.
V<-1:12
M2<-matrix(V,nrow=4,ncol=3)
M2


#4.
M3<-rbind(M1,M2)
M3

M4<-cbind(M1,M1)
M4


#5.
M5<-M3[1:2,1:2]
M5


#6.

M6<-t(M5)
M7<-M5%*%M6
M7



#7.
solve(M7)
det(M7)
