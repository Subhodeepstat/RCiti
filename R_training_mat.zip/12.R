data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

#1.
set.seed(1234)
data$ran_norm<-rnorm(nrow(data),0,1)


#2.
set.seed(1234)
data$gender<-factor(sample(c("M","F"),size=nrow(data),replace=TRUE))
head(data$gender)


#3.
set.seed(1234)
data$gender1<-factor(sample(c("M","F"),size=nrow(data),replace=TRUE,prob=c(0.45,0.55)))
head(data$gender1)

prop.table(table(data$gender1))



#4.
dim(data)

set.seed(1234)
idx<-sample(nrow(data),size=round(0.7*nrow(data)),replace=FALSE)


data_samp<-data[idx,]
head(data_samp)
dim(data_samp)
