
data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

#1.
set.seed(1234)
data$Response_date<-sample(seq(as.Date('1999/01/01'), as.Date('2000/01/01'), by="day"),size= nrow(data),replace=TRUE)
head(data$Response_date)

class(data$Response_date)

data$Response_date_2<-as.Date("2019-05-19",format="%Y-%m-%d")
head(data$Response_date_2)

##2.
data$weekdays<-weekdays.Date(data$Response_date)
head(data$weekdays)

###3.
data$days_ahead<-data$Response_date+14
head(data$days_ahead)
head(data$Response_date)


data$days_diff<-data$Response_date_2-data$Response_date
head(data$days_diff)
