data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

anyNA(data)

#1.
colnames(data)[colSums(is.na(data)) > 0]


#2.


length(data$V11[is.na(data$V11)==T])
which(is.na(data$V11))


#3.

data$V11<-ifelse(is.na(data$V11),0,data$V11)




#4.
sum(data$V30)
sum(data$V30,na.rm=T)


#5.
qt<-quantile(data$V28,probs=0.5,na.rm=T)###Median

data$V28<-ifelse(is.na(data$V28),qt,data$V28)


#6.Creating a data set where thye entire data sets are replaced

data1<-data
data1[is.na(data1)]<-0

head(data1)
anyNA(data1)



