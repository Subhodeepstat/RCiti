data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)
data1<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)



#1.

data_comb<-cbind(data,data1)


#2.
data2<-data1[1:100,]

data_merge<-merge(data,data2,by="Customer_id") ###outer join

dim(data_merge)
head(data_merge)

data_merge_l<-merge(data,data2,by="Customer_id",all.x=TRUE) ###Left join
data_merge_r<-merge(data,data2,by="Customer_id",all.y=TRUE) ###Right join
data_merge_i<-merge(data,data2,by="Customer_id",all.x=TRUE,all.y=TRUE) ###Inner join
data_merge_c<-merge(data,data2,by=NULL) ###Cross join


#3.
data_append<-rbind(data,data1)
