data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

#1.
data$gender_sort<-sort(data$gender,decrease=TRUE)
head(data$gender_sort)

#2.
data.sorted <- data[order(data$Customer_id) , ]  


