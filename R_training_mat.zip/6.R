#1.
age<-c(23,24,26,28)
english<-c(56,78,24,80)
science<-c(56,98,22,74)
name<-c("Rahul","Saikat","Suvadip","Akash")

#2.
data<-data.frame(age,english,science,name)


#3.
data$name

data[,3]


data[,c(2,4)]
data[1,]

#4.
data1<-data[-1,]
data2<-data1[,-1]
data2
