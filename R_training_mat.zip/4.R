#1.

x<-factor(c("yes", "yes", "no", "yes", "no"))
x

#2.

x <- factor(c("yes", "yes", "no", "yes", "no"), levels = c("yes", "no"))
x


#3.
table(x)
