data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

#1.
unique(data$Country)
data1<-subset(data,Region=="APAC" & Country=="India"  )

unique(data1$Country)


#2.

data2<-subset(data,select =-c(Region,Country,Target))

to_remove<-c("Region","Country","Target")

data3<-data[!colnames(data)%in%to_remove]

colnames(data3)



#3.

data4<-data[,grepl("Rev_",colnames(data))]
head(data4)

