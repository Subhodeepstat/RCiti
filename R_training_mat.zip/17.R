data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

#1.

anyDuplicated(data$Customer_id)

data$Customer_id[10]<-data$Customer_id[1]
anyDuplicated(data$Customer_id)

#2.

ids<-duplicated(data$Customer_id)
which(ids)

duplicated_data<-data[!ids,]


#3.
dups <- duplicated(data[,c("Customer_id","Target")])
duplicated_data_2<-data[!dups,]

head(duplicated_data_2)
