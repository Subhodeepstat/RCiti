data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)


#1.##
data$var_1<-data$V1/data$V2
head(data$var_1)


##2.##
data$var_subs<-substr(data$Country,1,2)
head(data$var_subs)


##3.##
colnames(data)[colnames(data)%in%"V4"]<-"prob"
head(data)
colnames(data)[colnames(data)%in%"V51"]<-"sales"
head(data)

##4.##
qt<-quantile(data$prob,probs=seq(0,1,0.1))
cut1<-cut(data$prob,breaks=qt,include.lowest = TRUE)
decile<-as.numeric(cut1)
table(decile)

data$decile<-decile

table(data$decile)
prop.table(table(data$decile))


##6.##
agg<-aggregate(sales~Target,FUN=sum,data=data)
agg
