data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)

class(data$Target)


#1.
data1<-data
data1$Customer_id<-as.character(data1$Customer_id)

class(data$Customer_id)
class(data1$Customer_id)


#2.

data1$Target1<-as.factor(data1$Target)
class(data1$Target1)

head(data1$Target1)

data1$Target2<-as.numeric(data1$Target1)

head(data1$Target2)

data1$Target3<-as.numeric(as.character(data1$Target1))

head(data1$Target3)


#3.

data1$Country2<-as.logical(data1$Country)
head(data1$Country2)


