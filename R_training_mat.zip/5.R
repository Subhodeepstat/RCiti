x<-1:20

y<-FALSE

z=30

M<-matrix(c(1:4),nrow=2,ncol=2)

desc<-"This is an example list"

mylst<-list(x,y,z,desc)

mylst



mylst[[1]]
class(mylst[[1]])
