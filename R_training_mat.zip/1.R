#1.

x<-64
y<-48
x;y;


#2.

x+y
x*y
x-y
x/y

#3.

x^(1/2)
log(x)

#4.
X<-5
x+X

#5.
X1<-7
X1

1X<-7
1X
