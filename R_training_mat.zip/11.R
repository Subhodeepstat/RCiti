data<-read.csv("C:\\THD\\R Training Folder\\data.csv",stringsAsFactors = T)


#1.
data$trend<-1:nrow(data)


#2.

data$var<-c(rep("Cards",10),rep("mortgage",nrow(data)-10))
head(data$var)



#3.
data$V85_log<-log(data$V85)
head(data$V85_log)


#4.
data$V2[50]
data$V2[50]<-50

data$V2[50]


