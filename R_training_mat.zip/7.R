#1.
setwd("C:\\THD\\R Training Folder\\")
getwd()

data<-read.csv("data.csv",stringsAsFactors = T)

#2.
head(data)
head(data,10)

#3.
str(data)

summary(data)


#4.
write.csv(data,file="data_write.csv",row.names = T)
write.csv(data,file="data_write_v2.csv",row.names = F)
