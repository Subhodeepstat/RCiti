#1.

V<-c(5+2i,6+3i,7+9i,12+3i,6+2i)
V


#2.
V1<-c(0.5,0.2)
V1


V2<-9:12
V2


#3.
V3<-V2[c(3,4)]
V3


#4.
V2[4]<-3
V4<-V3+V1


#5.
V5<-c(V4,V1)
length(V5)
class(V5)



#6.
V6<-c(6,"B")
V7<-c(TRUE,2)

class(V6)
class(V7)
